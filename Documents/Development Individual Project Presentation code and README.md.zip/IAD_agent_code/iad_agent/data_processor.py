import pandas as pd

class DataProcessor:
    def to_dataframe(self, records):
        df = pd.DataFrame.from_records(records, columns=["title","authors","year","url"])
        # Normalise whitespace, fill missing
        df["title"] = df["title"].fillna("").str.strip()
        df["authors"] = df["authors"].fillna("").str.replace("\s*;\s*", "; ", regex=True).str.strip()
        # Deduplicate
        df = df.drop_duplicates(subset=["title", "url"])
        # Year checks
        def fix_year(y):
            try:
                y = int(y)
                return y if 1900 <= y <= 2100 else None
            except Exception:
                return None
        df["year"] = df["year"].apply(fix_year)
        return df
