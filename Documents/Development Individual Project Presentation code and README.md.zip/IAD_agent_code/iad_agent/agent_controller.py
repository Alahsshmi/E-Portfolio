import os
from .logger import get_logger
from .scraper import Scraper
from .data_processor import DataProcessor
from .storage import StorageHandler

class AgentController:
    def __init__(self, out_dir: str):
        self.logger = get_logger()
        self.scraper = Scraper()
        self.processor = DataProcessor()
        self.storage = StorageHandler(out_dir)

    def run_from_html_file(self, html_path: str):
        self.logger.info("Loading HTML from %s", html_path)
        with open(html_path, "r", encoding="utf-8") as f:
            html_text = f.read()
        records = self.scraper.parse_static_html(html_text)
        self.logger.info("Parsed %d records", len(records))
        df = self.processor.to_dataframe(records)
        csv_path = self.storage.save_csv(df, "results.csv")
        xlsx_path = self.storage.save_excel(df, "results.xlsx")
        self.logger.info("Saved CSV to %s and Excel to %s", csv_path, xlsx_path)
        return df, csv_path, xlsx_path
