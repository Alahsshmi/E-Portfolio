# Academic Research Agent (Python)

Version tag: v1.0
Commit/tag for submission: v1.0

## What this does
A minimal, testable agent pipeline that:
- Parses representative HTML for article-like entries.
- Normalises records into a pandas DataFrame.
- Exports CSV and Excel outputs.
- Provides tests and evidence.

## How to run
```bash
python -m venv .venv && source .venv/bin/activate  # On Windows: .venv\Scripts\activate
pip install -r requirements.txt
python demo.py
```

Outputs appear in `outputs/`:
- `results.csv`
- `results.xlsx`

## How to test
```bash
python -m unittest tests/test_pipeline.py -v
```

## Project structure
```
iad_agent_code/
  iad_agent/
    __init__.py
    agent_controller.py
    scraper.py
    data_processor.py
    storage.py
    logger.py
  data/
    sample_page.html
  outputs/               # created at runtime
  tests/
    test_pipeline.py
  demo.py
  requirements.txt
  README.md
```

## Evidence mapping
Slides "Pipeline Overview" → `Evidence/pipeline_overview.png`
Slide "Preview of Structured Output" → `Evidence/dataframe_preview.png`
Slide "Year Distribution" → `Evidence/year_distribution.png`
Terminal run / tests → see screenshots and run locally using commands above.

## Design notes
- Modular separation improves clarity and testability.
- Static HTML parsing is the default; dynamic parsing can be added using Selenium when required.
- Data schema: title, authors, year, url. Deduplication and year checks applied.
- Logging captures key milestones for traceability.

## Ethics and academic integrity
- Respect source site policies for any live scraping.
- Cite sources in Harvard style in the presentation/transcript.
- This archive includes only synthetic/sample inputs to enable offline demonstration.
