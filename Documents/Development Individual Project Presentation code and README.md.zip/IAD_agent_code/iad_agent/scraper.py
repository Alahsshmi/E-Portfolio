from bs4 import BeautifulSoup

class Scraper:
    def parse_static_html(self, html_text: str):
        soup = BeautifulSoup(html_text, "html.parser")
        articles = []
        for div in soup.find_all("div", class_="article"):
            title = (div.find("h2").get_text(strip=True) if div.find("h2") else None)
            authors = (div.find("p", class_="authors").get_text(strip=True) 
                       if div.find("p", class_="authors") else "")
            year_text = (div.find("span", class_="year").get_text(strip=True) 
                         if div.find("span", class_="year") else "")
            url_tag = div.find("a")
            url = url_tag.get("href") if url_tag else ""
            try:
                year = int(year_text)
            except Exception:
                year = None
            articles.append({
                "title": title, "authors": authors, "year": year, "url": url
            })
        return articles
