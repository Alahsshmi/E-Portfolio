import os

class StorageHandler:
    def __init__(self, out_dir: str):
        os.makedirs(out_dir, exist_ok=True)
        self.out_dir = out_dir

    def save_csv(self, df, name: str = "results.csv"):
        path = os.path.join(self.out_dir, name)
        df.to_csv(path, index=False)
        return path

    def save_excel(self, df, name: str = "results.xlsx"):
        path = os.path.join(self.out_dir, name)
        df.to_excel(path, index=False)
        return path
