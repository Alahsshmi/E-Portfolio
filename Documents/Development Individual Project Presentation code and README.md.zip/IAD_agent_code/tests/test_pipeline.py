import os
import unittest
from iad_agent import AgentController

class TestPipeline(unittest.TestCase):
    def test_end_to_end(self):
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        data = os.path.join(base, "data", "sample_page.html")
        out = os.path.join(base, "outputs_test")
        agent = AgentController(out)
        df, csv_path, xlsx_path = agent.run_from_html_file(data)
        self.assertGreaterEqual(len(df), 1)
        self.assertTrue(os.path.exists(csv_path))
        self.assertTrue(os.path.exists(xlsx_path))

if __name__ == "__main__":
    unittest.main()
