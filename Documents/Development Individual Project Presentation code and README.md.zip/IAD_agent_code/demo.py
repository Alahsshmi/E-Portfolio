import os
from iad_agent import AgentController

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE_DIR, "data", "sample_page.html")
OUT = os.path.join(BASE_DIR, "outputs")

if __name__ == "__main__":
    agent = AgentController(OUT)
    df, csv_path, xlsx_path = agent.run_from_html_file(DATA)
    print("Preview:")
    print(df.head())
    print("\nSaved:")
    print(csv_path)
    print(xlsx_path)
